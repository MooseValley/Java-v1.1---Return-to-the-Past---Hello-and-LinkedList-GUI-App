# Java v1.x Going Back to the Beginning of Java in the mid-1990's

The code that goes with my video:
* Java v1.x Going Back to the Beginning of Java in the mid-1990's
https://youtu.be/IxYHpf-mEns

Java Programming Language (wikipedia):
* https://en.wikipedia.org/wiki/Java_(programming_language)

Oracle Java Archive (old version of Java JRE, SDK, etc):
* https://www.oracle.com/java/technologies/oracle-java-archive-downloads.html

VirtualBox (Windows, Mac, Linux, freeware):
* http://www.virtualbox.org/

TextPad (shareware):
* http://www.textpad.com/

VirusTotal (free scan against dozens of anti-malware and anti-virus checkers):
* http://www.virustotal.com/

Moose
Moose's Software Valley - Established July, 1996.
https://rebrand.ly/MoosesSoftware
